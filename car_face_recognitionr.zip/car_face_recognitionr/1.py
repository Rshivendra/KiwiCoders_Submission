# -*- coding:utf-8 -*-
"""
判断闰年条件：1.非整百年数除以4，无余为闰，有余为平2.整百年数除以400，无余为闰有余平
"""

for a in range(1,10):
    for b in range(1,10):
        if a>=b:
            print(f'{b}*{a}={a*b}',end='\t')
    print()




